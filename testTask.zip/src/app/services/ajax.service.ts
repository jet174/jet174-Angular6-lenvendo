import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const API_URL = 'http://newsapi.org/v2/';
const KEY = '95eeb5b5de4d4a91bbd629c40cf5afb7';

@Injectable({
  providedIn: 'root'
})
export class AjaxService {
  public data: any = [];

  constructor(private http: HttpClient) { }

  public GetUrl(url) {
    if (this.data.hasOwnProperty('articles')) {
      return;
    }

    return this.http.get(`${API_URL}/${url}&apiKey=${KEY}`)
    .subscribe(data => {
      console.log(data);
      this.data = data;
    });
  }

}
