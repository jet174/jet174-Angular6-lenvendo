import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import {Routes, RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';

import { CreateCardComponent } from './pages/create-card/create-card.component';
import {  HttpClientModule } from '@angular/common/http';
import { ClickOneTwoDirective } from './directive/click-one-two.directive';


const appRoutes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'create', component: CreateCardComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CreateCardComponent,
    ClickOneTwoDirective
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
