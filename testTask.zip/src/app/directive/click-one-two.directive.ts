import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appClickOneTwo]'
})
export class ClickOneTwoDirective {

  constructor(private _element: ElementRef) { }

  // tslint:disable-next-line:no-input-rename
  @Input('appClickOneTwo') ObjectCard: any;

  @HostListener('click') onClick() {
   this.ObjectCard.Active = this.ObjectCard.Active === 1 ? 0 : 1;
  // this._element.nativeElement.style.boxShadow = this.ObjectCard.Active === 1 ? '10px 20px 30px blue' : '';
  }
  @HostListener('dblclick') onDblClick() {
    if (!this.ObjectCard.HighBlock) {
      return;
    }
    this.ObjectCard.ColorCard = this.ObjectCard.ColorCard === 1 ? 2 : 1;
   // this._element.nativeElement.style.background = this.ObjectCard.ColorCard === 2 ? 'rgba(64, 255, 0, .4)' : 'rgba(255, 0, 0, .4)';
  }

}
