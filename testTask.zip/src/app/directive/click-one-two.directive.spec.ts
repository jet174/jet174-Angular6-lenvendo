import { ClickOneTwoDirective } from './click-one-two.directive';

describe('ClickOneTwoDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickOneTwoDirective();
    expect(directive).toBeTruthy();
  });
});
