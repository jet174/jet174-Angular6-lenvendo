import { Component, OnInit} from '@angular/core';
import { AjaxService } from '../../services/ajax.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    public Block = null;

  constructor(public newService: AjaxService, private router: Router) { }

  Perfomance(index) {
    return index;
  }

  PageCreateCard() {
    this.router.navigate(['/create']);
  }

  DeletBlock(item) {
    if (item.hasOwnProperty('HighBlock') && item.HighBlock) {
       return this.Block = item;
    }
    this.newService.data.articles = this.newService.data.articles.filter(data => data !== item);
    this.Block = null;
  }

  countAll(key: string, item) {
      return this.newService.data.hasOwnProperty('articles') ? this.newService.data.articles.filter(data => data[key] === item).length : 0;
  }

  getColor(card, block) {
    if (block) {
      return;
    }
   return card === 2 ? 'rgba(64, 255, 0, .4)' : 'rgba(255, 0, 0, .4)';
  }

  ngOnInit() {
      this.newService.GetUrl('top-headlines?country=us');
  }


}
