import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { AjaxService } from '../../services/ajax.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-card',
  templateUrl: './create-card.component.html',
  styleUrls: ['./create-card.component.css']
})
export class CreateCardComponent {
  signin = new FormGroup({
    title: new FormControl(null, Validators.required),
    text: new FormControl(null, Validators.required),
    checkbox: new FormControl(null)
  });

  HighBlock = false;
  constructor(public newService: AjaxService, private router: Router) { }

  onClickSubmit(data) {
    this.newService.data.articles.push(
      {
        // tslint:disable-next-line:no-shadowed-variable
        id: Math.max.apply(this.newService.data.articles.map(data => data.id)),
        title: data.title,
        description: data.text,
        HighBlock: data.checkbox
      }
    );
    this.router.navigate(['/']);
  }

}
